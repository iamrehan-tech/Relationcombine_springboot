package com.releationcombined;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationCombinespringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
