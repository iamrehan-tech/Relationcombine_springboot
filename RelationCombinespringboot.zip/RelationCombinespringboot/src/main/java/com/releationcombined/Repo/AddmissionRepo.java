package com.releationcombined.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.releationcombined.entity.Addmission;

public interface AddmissionRepo extends JpaRepository<Addmission,Integer> { 

}
